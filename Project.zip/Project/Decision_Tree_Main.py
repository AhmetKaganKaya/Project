import pandas as pd
import numpy as np
import decision_tree_functions as dt
import helper_functions as helper
import Random_Forest as rf
import time 
start_time = time.time()

#Data preprocessing
data_train = pd.read_csv("position_dataset_train20.csv")
X_train = data_train.drop(['Unnamed: 0'], axis=1)
y_train = data_train[['Position']]

data_test = pd.read_csv("position_dataset_test20.csv")
X_test = data_test.drop(['Unnamed: 0'], axis=1)
y_test = data_test[['Position']]

#K-Fold Cross Validattion
k = 10
accuracies = []
forests = {}
for i in range(0, len(X_train)//k ):
    X_test_data = X_train[i*k:i*k+k]
    y_test_data = y_train[i*k:i*k+k]
    X_train_data_below = X_train[0:i*k]
    y_train_data_below = y_train[0:i*k]
    X_train_data_above = X_train[i*k+k:len(X_train)]
    y_train_data_above = y_train[i*k+k:len(X_train)]
    X_train_data = pd.concat([X_train_data_below,X_train_data_above],axis = 0)
    y_train_data = pd.concat([y_train_data_below,y_train_data_above],axis = 0)
    
    del X_train_data_below,y_train_data_below,X_train_data_above,y_train_data_above
    
    forest = rf.random_forest_algorithm(X_train_data, 100, 50, 8, 20)
    result = rf.random_forest_predictions(X_test_data,forest)
    
        
    accuracy = helper.calculate_accuracy(result.values,y_test_data.values)
    forests[i] = forest
    accuracies.append(accuracy)
    
best_index = np.argmax(accuracies)
best_forest = forests[best_index]

del k,i,result

best_result = rf.random_forest_predictions(X_test,best_forest)
accuracy_of_best = helper.calculate_accuracy(best_result.values,y_test.values)

elapsed_time = time.time() - start_time
print(elapsed_time)