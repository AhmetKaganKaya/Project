import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

def sigmoid(x):
  return 1 / (1 + np.exp(-x))

def sigmoid_derivative(x):
  return sigmoid(x) * (1 - sigmoid(x))

def feedforward(x, weights1, weights2):
    layer1 = np.dot(x, weights1)
    output = sigmoid(np.dot(layer1, weights2))
    return output

def descent(X,y,weights1,weights2,output):
    layer1 = np.dot(X, weights1)
    output = sigmoid(np.dot(layer1, weights2))
    sigma = np.multiply(2*(y - output), sigmoid_derivative(output))
    d_weights2 = np.dot(layer1.T, sigma)
    d_weights1 = np.dot(X.T,np.dot(sigma, weights2.T) )
    weights1 += 0.0001*d_weights1
    weights2 += 0.0001*d_weights2
    return weights1,weights2

def determine_array(arr):
    arr2 = np.random.rand(arr.shape[0],arr.shape[1])
    for i in range(0,arr.shape[0]):
        index = arr[i].argmax()
        for j in range(0,arr.shape[1]):
            if j == index:
                arr2[i][j] = 1
            else:
                arr2[i][j] = 0
    return arr2
            
def accuracy(result,test):
    counter = 0
    for i in range(0,result.shape[0]):
        for j in range(0,result.shape[1]):
            if result[i][j] == test[i][j]:
                counter += 1
    accuracy = counter / (result.shape[0]*result.shape[1])
    return accuracy
    
def k_fold_cross_validation(X_data,y_data,k):
    accuracy_functions = []
    weights = []
    k = int(input("Number of K-fold cross validation = "))
    # K-fold cross validation
    for i in range(0, X_data.shape[0]//k ):
        X_test_data = X_data[i*k:i*k+k ,:]
        y_test_data = y_data[i*k:i*k+k,:]
        X_train_data = X_data
        y_train_data = y_data
        for m in range(i*k,i*k+k):
            X_train_data = np.delete(X_train_data,i*k,0)
            y_train_data = np.delete(y_train_data,i*k,0)
    
        weights1   = np.random.rand(X_train.shape[1],(y_train.shape[0] *2) //3) 
        weights2   = np.random.rand((y_train.shape[0] *2) //3,3)                 
        output     = np.zeros((y_train.shape[0],3))  
        
        for _ in range(1000):
            weights1,weights2 = descent(X_train_data,y_train_data,weights1,weights2,output)
            
        weights.append(weights1)
        weights.append(weights2)
        result = feedforward(X_test_data, weights1, weights2)
        overall_accuracy = accuracy(result,y_test_data)
        accuracy_functions.append(overall_accuracy)
    
    # Choosing best model
    best_model_index = np.argmax(accuracy_functions)
    best_weights1 =  weights[2*best_model_index]   
    best_weights2 =  weights[2*best_model_index+1]   
    return best_weights1,best_weights2

#DATA PREPROCESSING
data_test = pd.read_csv("neural_dataset_train2.csv")
X_train = data_test.drop(['Position','Unnamed: 0'], axis=1).values
y_train = data_test[['Position']].values

from sklearn.preprocessing import LabelEncoder, OneHotEncoder
labelencoder_y = LabelEncoder()
y_train[:, 0] = labelencoder_y.fit_transform(y_train[:, 0])
onehotencoder = OneHotEncoder(categorical_features = [0])
y_train = onehotencoder.fit_transform(y_train).toarray()

from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train = sc.fit_transform(X_train)

data_test = pd.read_csv("neural_dataset_test2.csv")
X_test = data_test.drop(['Position','Unnamed: 0'], axis=1).values
y_test = data_test[['Position']].values

from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_test = sc.fit_transform(X_test)

from sklearn.preprocessing import LabelEncoder, OneHotEncoder
labelencoder_y = LabelEncoder()
y_test[:, 0] = labelencoder_y.fit_transform(y_test[:, 0])
onehotencoder = OneHotEncoder(categorical_features = [0])
y_test = onehotencoder.fit_transform(y_test).toarray()


weight1,weight2 = k_fold_cross_validation(X_train,y_train,True)



output = feedforward(X_test,weight1,weight2)
output = determine_array(output)
accuracy = accuracy(output,y_test)