import numpy as np
import pandas as pd
import decision_tree_functions as dt
import helper_functions as helper

def bootstrapping(df, number):
    indices = np.random.randint(low=0, high= len(df), size=number)
    bootstrapped_data = df.iloc[indices]
    
    return bootstrapped_data

def random_forest_algorithm(df, number_bootstrapping, number_trees, number_feature, number_depth):
    forest = []
    
    for i in range(number_trees):
        bootstrepped_data = bootstrapping(df, number_bootstrapping)
        tree = dt.decision_tree_algorithm(bootstrepped_data, max_depth = number_depth, random_subspace = number_feature)
        forest.append(tree)
        
        
    return forest

def random_forest_predictions(df, forest):
    df_predictions = {}
    
    for i in range(0,len(forest)):
        predictions = dt.decision_tree_predictions(df, tree = forest[i])
        df_predictions[i] = predictions
       
    df_predictions = pd.DataFrame(df_predictions)
    random_forest_predictions = df_predictions.mode(axis=1)[0]
    return random_forest_predictions