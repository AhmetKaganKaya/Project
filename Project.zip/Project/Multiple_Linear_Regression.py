import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

def feedforward(x_data,w):
    return np.dot(x_data,w)

def calculate_error(x_data,y_data,w):
    error = y_data - feedforward(x_data,w)
    return np.dot(error.T,error)

def gradient_descent(x_data,y_data,iteration_number):
    w = np.random.randn(x_data.shape[1],1)
    z = np.dot(x_data,w) 
    for i in range(0,iteration_number):  
        error = z - y_data
        gradient = np.dot(x_data.T,error)/(y_data.shape[0])
        w = w - 0.001*gradient
        z = np.dot(x_data,w)
    return w

def forward_selection(df,x_data,y_data,number_feature):
    
    indexes = []
    indexes_name = {}
    new_data = np.array(None)
    for k in range(0,number_feature):
        errors = []
        for i in range(0,x_data.shape[1]):
            new_data = np.array(x_data)[:,indexes]
            new_data = np.concatenate((new_data,np.array(x_data)[:,i:i+1]),axis=1)
            weight = gradient_descent(new_data,y_data,100000)
            errors.append(calculate_error(new_data,y_data,weight))
        index = np.argmin(errors)
        indexes.append(index)
        indexes_name[k] = list(df.columns)[index + 1]
    return indexes_name



def k_fold_cross_validation(X_data,y_data,k):
    cost_functions = []
    weights = []
    k = int(input("Number of K-fold cross validation = "))
    # K-fold cross validation
    for i in range(0, X_data.shape[0]//k ):
        X_test_data = X_data[i*k:i*k+k ,:]
        y_test_data = y_data[i*k:i*k+k,:]
        X_train_data = X_data
        y_train_data = y_data
        for m in range(i*k,i*k+k):
            X_train_data = np.delete(X_train_data,i*k,0)
            y_train_data = np.delete(y_train_data,i*k,0)
            
        w = gradient_descent(X_train_data,y_train_data,100000)
            
        weights.append(w)
        overall_error = calculate_error(X_test_data,y_test_data,w)
        cost_functions.append(overall_error)
    
    # Choosing best model
    best_model_index = np.argmin(cost_functions)
    best_weight =  weights[best_model_index]   
    return best_weight

# DATA PREPROCESSING*******************************
    data_train = pd.read_csv("regression_train.csv")
    X_train = data_train.drop(['Release Clause','Unnamed: 0'], axis=1).values
    y_train = data_train[['Release Clause']].values

    from sklearn.preprocessing import StandardScaler
    sc = StandardScaler()
    X_train = sc.fit_transform(X_train)
    from sklearn.preprocessing import StandardScaler
    sc = StandardScaler()
    y_train = sc.fit_transform(y_train)
    
    data_test = pd.read_csv("regression_test.csv")
    X_test = data_test.drop(['Release Clause','Unnamed: 0'], axis=1).values
    y_test = data_test[['Release Clause']].values
    
    from sklearn.preprocessing import StandardScaler
    sc = StandardScaler()
    X_test = sc.fit_transform(X_test)
    from sklearn.preprocessing import StandardScaler
    sc = StandardScaler()
    y_test = sc.fit_transform(y_test)
#************************************************
#    
    best_weight = k_fold_cross_validation(X_train,y_train,True)
    
#    forward_selection(data_train,X_train,y_train,9)
    
    result = feedforward(X_test,best_weight)
    
    