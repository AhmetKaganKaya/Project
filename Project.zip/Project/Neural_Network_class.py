import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import time
start_time = time.time()


data_train = pd.read_csv("position_dataset_train.csv")
X_train = data_train.drop(['Position', 'Unnamed: 0'], axis=1).values

positions = data_train[['Position']].values
data_train = data_train.drop(['Position'], axis=1)

data_train['DEF'] = positions
data_train = data_train.astype({'DEF': str})
data_train = data_train.replace({"2":0, "2":0, "2":0,"1":0,"2":0,"2":0,"0":1,"1":0,
                                             "0":1,"1":0,"1":0,"1":0,"2":0,"0":1,"1":0,"1":0,"2":0,
                                             "1":0,"0":1,"0":1,"1":0,"1":0,"1":0,"0":1,"0":1, "2":0})
data_train['MID'] = positions
data_train = data_train.astype({'MID': str})
data_train = data_train.replace({"2":0, "2":0, "2":0,"1":1,"2":0,"2":0,"0":0,"1":1,
                                             "0":0,"1":1,"1":1,"1":1,"2":0,"0":0,"1":1,"1":1,"2":0,
                                             "1":1,"0":0,"0":0,"1":1,"1":1,"1":1,"0":0,"0":0, "2":0})
data_train['ATK'] = positions
data_train = data_train.astype({'ATK': str})
data_train = data_train.replace({"2":1, "2":1, "2":1,"1":0,"2":1,"2":1,"0":0,"1":0,
                                             "0":0,"1":0,"1":0,"1":0,"2":1,"0":0,"1":0,"1":0,"2":1,
                                             "1":0,"0":0,"0":0,"1":0,"1":0,"1":0,"0":0,"0":0, "2":1})
y_train = data_train[['DEF','MID','ATK']].values

#%%
def sigmoid(x):
    return 1 / (1 + np.exp(-x))


def sigmoid_derivative(x):
    return sigmoid(x) * (1 - sigmoid(x))


def feedforward(x, weights1, weights2):
    layer1 = np.dot(x, weights1)
    output = sigmoid(np.dot(layer1, weights2))
    return output


def descent(X, y, weights1, weights2, output):
    layer1 = np.dot(X, weights1)
    output = sigmoid(np.dot(layer1, weights2))
    sigma = np.multiply(2 * (y - output), sigmoid_derivative(output))
    d_weights2 = np.dot(layer1.T, sigma)
    d_weights1 = np.dot(X.T, np.dot(sigma, weights2.T))
    weights1 += 0.001 * d_weights1
    weights2 += 0.001 * d_weights2


def determine_array(arr):
    arr2 = np.random.rand(arr.shape[0], arr.shape[1])
    for i in range(0, arr.shape[0]):
        index = arr[i].argmax()
        for j in range(0, arr.shape[1]):
            if j == index:
                arr2[i][j] = 1
            else:
                arr2[i][j] = 0
    return arr2


def accuracy(result, test):
    counter = 0
    for i in range(0, result.shape[0]):
        for j in range(0, result.shape[1]):
            if int(result[i][j]) == test[i][j]:
                counter += 1
    accuracy = counter / (result.shape[0] * result.shape[1])
    return accuracy

# from sklearn.preprocessing import LabelEncoder, OneHotEncoder
#
# labelencoder_y = LabelEncoder()
# y_train[:, 0] = labelencoder_y.fit_transform(y_train[:, 0])
# onehotencoder = OneHotEncoder(categorical_features=[0])
# y_train = onehotencoder.fit_transform(y_train).toarray()

# from sklearn.preprocessing import LabelEncoder, OneHotEncoder
#
# labelencoder_y = LabelEncoder()
# y_test[:, 0] = labelencoder_y.fit_transform(y_test[:, 0])
# onehotencoder = OneHotEncoder(categorical_features=[0])
# y_test = onehotencoder.fit_transform(y_test).toarray()

#%%
X_train = pd.DataFrame(data=X_train)
y_train = pd.DataFrame(data=y_train)
# K-Fold Cross Validattion
k = 10
accuracies = []
weights = []
for i in range(0, len(X_train) // k):
    X_test_data = X_train[i * k:i * k + k]
    y_test_data = y_train[i * k:i * k + k]
    X_train_data_below = X_train[0:i * k]
    y_train_data_below = y_train[0:i * k]
    X_train_data_above = X_train[i * k + k:len(X_train)]
    y_train_data_above = y_train[i * k + k:len(X_train)]
    X_train_data = pd.concat([X_train_data_below, X_train_data_above], axis=0)
    y_train_data = pd.concat([y_train_data_below, y_train_data_above], axis=0)
    # del X_train_data_below, y_train_data_below, X_train_data_above, y_train_data_above

    from sklearn.preprocessing import StandardScaler
    sc = StandardScaler()
    X_train_data = sc.fit_transform(X_train_data)

    weights1 = np.random.rand(X_train_data.shape[1], (y_train_data.shape[0] * 2) // 3)
    weights2 = np.random.rand((y_train_data.shape[0] * 2) // 3, 3)
    output = np.zeros((y_train_data.shape[0], 3))
    #
    for i in range(1, 20000):
        descent(X_train_data, y_train_data, weights1, weights2, output)

    output = feedforward(X_test_data, weights1, weights2)
    output = determine_array(output)

    y_test_array = y_test_data.to_numpy()
    accuracy = accuracy(output, y_test_array)
    accuracies.append(accuracy)
    weights.append(weights1)
    weights.append(weights2)
#%%
print(accuracies)
best_index = np.argmax(accuracies)
weights1_test = weights[2*best_index-2]
weights2_test = weights[2*best_index-1]

del weights, best_index, k, i, output

#%%
data_test = pd.read_csv("position_dataset_test.csv")
X_test = data_test.drop(['Position', 'Unnamed: 0'], axis=1).values
positions = data_test[['Position']].values
data_test = data_test.drop(['Position'], axis=1)

data_test['DEF'] = positions
data_test = data_test.astype({'DEF': str})
data_test = data_test.replace({"2":0, "2":0, "2":0,"1":0,"2":0,"2":0,"0":1,"1":0,
                                             "0":1,"1":0,"1":0,"1":0,"2":0,"0":1,"1":0,"1":0,"2":0,
                                             "1":0,"0":1,"0":1,"1":0,"1":0,"1":0,"0":1,"0":1, "2":0})
data_test['MID'] = positions
data_test = data_test.astype({'MID': str})
data_test = data_test.replace({"2":0, "2":0, "2":0,"1":1,"2":0,"2":0,"0":0,"1":1,
                                             "0":0,"1":1,"1":1,"1":1,"2":0,"0":0,"1":1,"1":1,"2":0,
                                             "1":1,"0":0,"0":0,"1":1,"1":1,"1":1,"0":0,"0":0, "2":0})
data_test['ATK'] = positions
data_test = data_test.astype({'ATK': str})
data_test = data_test.replace({"2":1, "2":1, "2":1,"1":0,"2":1,"2":1,"0":0,"1":0,
                                             "0":0,"1":0,"1":0,"1":0,"2":1,"0":0,"1":0,"1":0,"2":1,
                                             "1":0,"0":0,"0":0,"1":0,"1":0,"1":0,"0":0,"0":0, "2":1})
y_test = data_test[['DEF','MID','ATK']].values
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_test = sc.fit_transform(X_test)

output = feedforward(X_test, weights1, weights2)
output = determine_array(output)
#%%
accuracy = accuracy(output, y_test)
elapsed_time = time.time() - start_time
print(elapsed_time)