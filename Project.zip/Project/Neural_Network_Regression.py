import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

def feedforward(x, weights1, weights2):
    layer1 = np.dot(x, weights1)
    output = np.dot(layer1, weights2)
    return output

def calculate_error(x,weights1, weights2,y):
    error = y - feedforward(x, weights1, weights2)
    return np.dot(error.T,error)

def descent(x,y,weights1,weights2):
    error = y - feedforward(x, weights1, weights2)
    d_weights1 = 2*np.dot(x.T,np.dot(error,weights2.T))/y.shape[0]
    d_weights2 = np.dot(np.dot(weights1.T,x.T),2*error)/y.shape[0]
    weights1 += 0.0001*d_weights1
    weights2 += 0.0001*d_weights2
    return weights1,weights2
    
def k_fold_cross_validation(X_data,y_data,k):
    cost_functions = []
    weights = []
    k = int(input("Number of K-fold cross validation = "))
    # K-fold cross validation
    for i in range(0, X_data.shape[0]//k ):
        X_test_data = X_data[i*k:i*k+k ,:]
        y_test_data = y_data[i*k:i*k+k,:]
        X_train_data = X_data
        y_train_data = y_data
        for m in range(i*k,i*k+k):
            X_train_data = np.delete(X_train_data,i*k,0)
            y_train_data = np.delete(y_train_data,i*k,0)
            
        weights1   = np.random.rand(X_train.shape[1],(y_train.shape[0] *2) //3) 
        weights2   = np.random.rand((y_train.shape[0] *2) //3,1)                 
        
        iteration_number = 50000
        for i in range(0,iteration_number):
            weights1,weights2 = descent(X_train_data,y_train_data,weights1,weights2)
    
        weights.append(weights1)
        weights.append(weights2)
        overall_error = calculate_error(X_test_data,weights1,weights2,y_test_data)
        cost_functions.append(overall_error)
    
    # Choosing best model
    best_model_index = np.argmin(cost_functions)
    best_weight1 =  weights[best_model_index*2]   
    best_weight2 =  weights[best_model_index*2 + 1] 
    return best_weight1,best_weight2
    

# DATA PREPROCESSING*******************************
data_test = pd.read_csv("regression_train.csv")
X_train = data_test.drop('Release Clause', axis=1).values
y_train = data_test[['Release Clause']].values

from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
y_train = sc.fit_transform(y_train)

data_test = pd.read_csv("regression_test.csv")
X_test = data_test.drop('Release Clause', axis=1).values
y_test = data_test[['Release Clause']].values

from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_test = sc.fit_transform(X_test)
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
y_test = sc.fit_transform(y_test)
#************************************************

best_weight1,best_weight2 = k_fold_cross_validation(X_train,y_train,True)

result = feedforward(X_test,best_weight1,best_weight2)